import java.awt.*;
import java.awt.event.*;
import javax.swing.plaf.ColorUIResource;
public class AWTLoginForm extends Frame implements ActionListener  
{
    Label userLabel,passLabel,messageLabel;
    TextField userText,passText;
    Button loginButton;

    public AWTLoginForm()
    {
        setTitle("Login Form - AWT");
        setSize(350,200);
        setLayout(null);
        setVisible(true);
        setLocationRelativeTo(null);

        userLabel=new Label("Username:");
        userLabel.setBounds(50,50,80,20);
        add(userLabel);

        userText=new TextField();
        userText.setBounds(140,50,130,20);
        add(userText);

        passLabel=new Label("Password:");
        passLabel.setBounds(50,80,80,20);
        add(passLabel);

        passText=new TextField();
        passText.setEchoChar('*');
        passText.setBounds(140,80,130,20);
        add(passText);

        loginButton=new Button("Login");
        loginButton.setBounds(130,120,80,25);
        loginButton.addActionListener(this);
        add(loginButton);

        messageLabel = new Label();
        messageLabel.setBounds(50, 150, 250, 20);
        add(messageLabel);

        addWindowListener(new WindowAdapter() 
        {
            public void windowClosing(WindowEvent e)
            {
                dispose();
            }
        });

    }

    @Override

    public void actionPerformed(ActionEvent e)
    {
        String Username=userText.getText();
        String password=passText.getText();

        if(Username.equals("admin")&&password.equals("123"))
        {
            messageLabel.setText("Login Succesfully!");
            messageLabel.setForeground(ColorUIResource.GREEN);

        }
        else
        {
            messageLabel.setText("Invalid username or password.");
            messageLabel.setForeground(ColorUIResource.RED);

        }
    }
    public static void main(String[] args) 
    {
        new AWTLoginForm();    
    }
}
